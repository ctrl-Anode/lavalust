<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class ClassesController extends Controller {
    public function __construct()
    {
        parent:: __construct();
        $this->call->model('classes_model');
    }
	public function read()
    {
        $userdata['classes']=$this->classes_model->read();
        $this->call->view('gymclasses/view_class', $userdata);
    }
    public function create()
    {
        if($this->form_validation->submitted()){
            $this->form_validation
                ->name('ClassType')
                     ->required('ClassType is required!')
                ->name('Description')
                     ->required('Description is required!')
                ->name('DurationInMinutes')
                     ->required('DurationInMinutes is required!')
                ->name('Price')
                     ->required('Price is required!')
                ->name('GymInstructor')
                     ->required('GymInstructor is required!')
                ->name('Schedule')
                     ->required('Schedule is required!');
        if($this->form_validation->run()){
            $ClassType = $this->io->post('ClassType');
            $Description = $this->io->post('Description');
            $DurationInMinutes = $this->io->post('DurationInMinutes');
            $Price = $this->io->post('Price');
            $GymInstructor = $this->io->post('GymInstructor');
            $Schedule = $this->io->post('Schedule');

            if($this->classes_model->create($ClassType, $Description, $DurationInMinutes, $Price, $GymInstructor, $Schedule)){
               set_flash_alert('success', 'Class was added successfully!');
               redirect('auth/class/display');
            }
        }
        else{
               set_flash_alert('danger', $this->form_validation->errors());
               redirect('auth/class/add');
        }
        }
        $this->call->view('gymclasses/add_class');
    }
    public function update($id)
{
    if ($this->form_validation->submitted()) {
        // Define validation rules
        $this->form_validation
        ->name('ClassType')
        ->required('ClassType is required!')
   ->name('Description')
        ->required('Description is required!')
   ->name('DurationInMinutes')
        ->required('DurationInMinutes is required!')
   ->name('Price')
        ->required('Price is required!')
   ->name('GymInstructor')
        ->required('GymInstructor is required!')
   ->name('Schedule')
        ->required('Schedule is required!');

        // Run validation
        if ($this->form_validation->run()) {
            // Collect form data
            $data = [
                'ClassType' => $this->io->post('ClassType'),
                'Description' => $this->io->post('Description'),
                'DurationInMinutes' => $this->io->post('DurationInMinutes'),
                'Price' => $this->io->post('Price'),
                'GymInstructor' => $this->io->post('GymInstructor'),
                'Schedule' => $this->io->post('Schedule'),
            ];

            // Update user data in the database
            if ($this->classes_model->update($id, $data)) {
                set_flash_alert('success', 'User data was updated successfully!');
                redirect('auth/class/display');
                return;
            } else {
                set_flash_alert('danger', 'Failed to update user data.');
                redirect('auth/class/display');
                return;
            }
        } else {
            // Handle validation errors
            set_flash_alert('danger', $this->form_validation->errors());
            redirect('auth/class/display');
            return;
        }
    }

    // Load user data for the view
    $userdata['class'] = $this->classes_model->get_one($id);
    $this->call->view('gymclasses/edit_class', $userdata);
}

    public function delete($id){
        if($this->classes_model->delete($id)){
            set_flash_alert('success', 'User data was deleted successfully!');
            redirect('auth/class/display');
        }else{
            set_flash_alert('danger', 'Something Went Wrong!');
            redirect('auth/class/display');
        }
    }
    
}
?>
