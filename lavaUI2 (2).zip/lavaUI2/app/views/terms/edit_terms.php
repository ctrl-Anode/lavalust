<?php
    include APP_DIR.'views/templates/adminsidebar.php';
    ?>
    <h1>Edit Term</h1>
<form action="<?=site_url('auth/terms/update/' . $term['TermID']);?>" method="POST">
    <label for="TermText">Term Text:</label>
    <textarea name="TermText" required><?= $term['TermText']; ?></textarea>
    <label for="status">Status:</label>
    <input type="text" name="status" value="<?= $term['status']; ?>" required>
    <button type="submit">Update Term</button>
</form>
