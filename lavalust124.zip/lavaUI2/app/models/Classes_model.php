<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class Classes_model extends Model {
	public function read(){
        return $this->db->table('Classes')->get_all();
    }
    public function create($ClassType, $Description, $DurationInMinutes, $Price, $GymInstructor	, $Schedule){
        $userdata = array(
            'ClassType' => $ClassType, 'Description' => $Description, 'DurationInMinutes' => $DurationInMinutes, 'Price' => $Price, 'GymInstructor	' => $GymInstructor	, 'Schedule' => $Schedule
        );
        return $this->db->table('Classes')->insert($userdata);
    }
    public function get_one($id){
        return $this->db->table('Classes')->where('ClassID', $id)->get();
    }
    public function update($id, $data) {
        // Ensure $data contains all necessary keys to avoid errors
        $userdata = [
            'ClassType' => $data['ClassType'],
            'Description' => $data['Description'],
            'DurationInMinutes' => $data['DurationInMinutes'],
            'Price' => $data['Price'],
            'GymInstructor	' => $data['GymInstructor'],
            'Schedule' => $data['Schedule'],
        ];
    
        // Execute the update query
        return $this->db->table('Classes')->where('ClassID', $id)->update($userdata);
    }
    
    public function delete($id){
        return $this->db->table('Classes')->where('ClassID', $id)->delete();
    }
    public function avail($ClassType, $Description, $DurationInMinutes, $Price, $GymInstructor	, $Schedule){
        $userdata = array(
            'ClassType' => $ClassType, 'Description' => $Description, 'DurationInMinutes' => $DurationInMinutes, 'Price' => $Price, 'GymInstructor	' => $GymInstructor	, 'Schedule' => $Schedule
        );
        return $this->db->table('UserClass')->insert($userdata);
    }
}
?>
