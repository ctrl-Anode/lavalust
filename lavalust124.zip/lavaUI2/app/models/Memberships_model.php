<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class Memberships_model extends Model {
	public function read(){
        return $this->db->table('Memberships')->get_all();
    }
    public function apply($MembershipType, $MembershipPrice, $MembershipInfo, $DurationInMonths){
        $userdata = array(
            'MembershipType' => $MembershipType, 'MembershipPrice' => $MembershipPrice, 'MembershipInfo' => $MembershipInfo, 'DurationInMonths' => $DurationInMonths
        );
        return $this->db->table('Memberships')->insert($userdata);
    }
    public function get_one($id){
        return $this->db->table('Memberships')->where('MembershipID', $id)->get();
    }
    public function update($id, $data) {
        // Ensure $data contains all necessary keys to avoid errors
        $userdata = [
            'MembershipType' => $data['MembershipType'],
            'MembershipPrice' => $data['MembershipPrice'],
            'MembershipInfo' => $data['MembershipInfo'],
            'DurationInMonths' => $data['DurationInMonths'],
        ];
    
        // Execute the update query
        return $this->db->table('Memberships')->where('MembershipID', $id)->update($userdata);
    }
    
    public function delete($id){
        return $this->db->table('Memberships')->where('MembershipID', $id)->delete();
    }
    public function avail($MembershipType, $MembershipPrice, $MembershipInfo, $DurationInMonths){
        $userdata = array(
            'MembershipType' => $MembershipType, 'MembershipPrice' => $MembershipPrice, 'MembershipInfo' => $MembershipInfo, 'DurationInMonths' => $DurationInMonths
        );
        return $this->db->table('UserMem')->insert($userdata);
    }
    public function mem_delete($id){
        return $this->db->table('UserMem')->where('MembershipID', $id)->delete();
    }
}
?>
